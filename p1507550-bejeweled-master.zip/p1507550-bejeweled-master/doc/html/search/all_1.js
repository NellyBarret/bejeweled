var searchData=
[
  ['count_5fscore',['count_score',['../classGrid.html#a3d8794671a4307e4447b947f483a9a87',1,'Grid']]]
];
