/* 
Grid.cpp
Nelly BARRET - 11507461
Monica LISACEK - 11507550
Hanna PARSHUTO - 11512677
*/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cassert>
#include <time.h>

#include "Grid.h"
#include "Jewel.h"

using namespace std;


Grid::Grid ()
{
    xdim = 0;
    ydim = 0;
    score = 0;
    
    table = new char*[0];
    table[0] = new char[0];

    cout << "A grid of size " << xdim << "*" << ydim << " has been created." << endl << endl;
}

Grid::Grid (unsigned int dimensionX, unsigned int dimensionY)
{ 
    unsigned int i;
    xdim = dimensionX;
    ydim = dimensionY;
    score = 0;
    
    table = new char*[ydim];
    
    //for each row, we create xdim columns.
    for(i = 0; i < ydim; ++i)
    {
        table[i] = new char[xdim];
    }

    cout << "A grid of size " << xdim << "*" << ydim << " has been created." << endl;
}

Grid::~Grid ()
{
    unsigned int i;

    for (i = 0 ; i < ydim ; ++i)
    {
        delete [] table[i];
    }

    delete [] table;
    
    xdim = 0; //column
    ydim = 0; //row
    
    cout << "The grid has been deleted." << endl << endl;
}


void Grid::initialize_grid (const char carac)
{
    for(unsigned int i = 0 ; i < ydim ; i++)
    {
        for(unsigned int j = 0 ; j < xdim ; j++)
        {
            table[i][j] = carac;
        }
    }
}

char Grid::random_jewel (int min, int max)
{
    int range = max - min + 1;
    
    //we generate a character bewteen 65 ('A') and 71 ('G') (7 jewels)
    //this calculation is like rand()%7+65 but it will be valid even if the size of grid changes
    
    return (rand()%(range) + min);
}

void Grid::display_grid ()
{
    unsigned int i, j;

    cout << "  +---+---+---+---+---+---+---+---+" << endl;
    
    for (i = 0 ; i <  xdim ; i++)
    {
        cout << i+1 << " ";

        for (j = 0 ; j < ydim ; j ++)
        {
            cout << "| " << table[i][j] << " ";
        }

        cout << "|" << endl;
        cout << "  +---+---+---+---+---+---+---+---+" << endl;
    }

    cout << "    1   2   3   4   5   6   7   8" << endl << endl;
}

void Grid::fill_grid_jewel ()
{
    unsigned int i, j;
    
    //in order to have pseudo-random jewels
    srand (time(NULL));

    for (i = 0 ; i < xdim ; i++)
    {
        for (j = 0 ; j < ydim ; j++)
        {
            table[i][j] = random_jewel(65,71);
        }
    }
}

void Grid::alignment_verification (int &nbAlignR3, int &nbAlignR4, int &nbAlignR5, int &nbAlignC3, int &nbAlignC4, int &nbAlignC5)
{
    unsigned int i, j;
    int k;
    bool align_OK; //if one alignment is found
    int nb_verif; //from 5 to 3
    int max; //the last verified jewel
    bool last_verif = false; //true if there is no alignment after the swap
    bool random_done = false;
    
    //number of alignments per row 
    nbAlignR3 = 0;
    nbAlignR4 = 0;
    nbAlignR5 = 0;

    //number of alignments per column
    nbAlignC3 = 0;
    nbAlignC4 = 0;
    nbAlignC5 = 0;
    
    //if there is a good combination, we replace the jewels by others.
    //first with 5 then 4 then 3 in order to delete 5 in first (otherwise we delete 3 in an alignment of 5)
       
    while(last_verif == false)
    {
        //by default, this is the last verification
        last_verif = true;    
        
        //the length of alignment
        for(nb_verif = 5 ; nb_verif >= 3 ; nb_verif--)
        {
            max = nb_verif;

            //going through the table vertically
            for(i = 0 ; i < xdim ; i++)
            {
                //going through the table horizontally
                for(j = 0 ; j < ydim ; j++)
                {
                    //the max value must be inferior to the grid length
                    if(j+(max-1) < ydim)
                    {
                        //as soon as a cell is not equal to the first, the alignment will never exist
                        align_OK = true;

                        for(k = 0 ; k < max ; k++)
                        {
                            if(table[i][j] != table[i][j+k])
                            {
                                align_OK = false;
                            }
                        }

                        //we increment the variable for the corresponding length
                        if(align_OK == true)
                        {
                            //we have found an alignement -> this is not the last verification
                            last_verif = false;
                            
                            if(random_done == false)
                            {
                                switch(nb_verif)
                                {
                                    case 3:
                                    {
                                        nbAlignR3++;
                                        break;
                                    }

                                    case 4:
                                    {
                                        nbAlignR4++;
                                        break;
                                    }

                                    case 5:
                                    {
                                        nbAlignR5++;
                                        break;
                                    }
                                }
                            }

                            //for each cell of the alignment, we replace it with an new random jewel
                            for(k = 0 ; k < max ; k++)
                            {
                                table[i][j+k] = random_jewel(65,71);
                            }

                            random_done = true;

                            //if an alignment of 5 is found, no alignment of 4 or 3 is possible -> break the for
                            nb_verif = 2;
                        }
                    }
                }
            }
        }

        //the length of alignment
        for(nb_verif = 5 ; nb_verif >= 3 ; nb_verif--)
        {
            max = nb_verif;

            //going through the table vertically
            for(i = 0 ; i < xdim ; i++)
            {
                //going through the table horizontally
                for(j = 0 ; j < ydim ; j++)
                {
                    //the max value must be inferior the the grid length
                    if(i+(max-1) < xdim)
                    {
                        //as soon as a cell is not equal to the first, the alignment will never exist
                        align_OK = true;

                        for(k = 0 ; k < max ; k++)
                        {
                            if(table[i][j] != table[i+k][j])
                            {
                                align_OK = false;
                            }
                        }

                        //we increment the variable for the corresponding length
                        if(align_OK == true)
                        {
                            //we have found an alignement -> this is not the last verification
                            last_verif = false;
                            
                            if(random_done == false)
                            {
                                switch(nb_verif)
                                {
                                    case 3:
                                    {
                                        nbAlignC3++;
                                        break;
                                    }

                                    case 4:
                                    {
                                        nbAlignC4++;
                                        break;
                                    }

                                    case 5:
                                    {
                                        nbAlignC5++;
                                        break;
                                    }
                                }
                            }

                            //for each cell of the alignment, we repalce it with an new random jewel
                            for(k = 0 ; k < max ; k++)
                            {
                                table[i+k][j] = random_jewel(65,71);
                            }

                            random_done = true;

                            //if an alignment of 5 is found, no alignment of 4 or 3 is possible -> break the for
                            nb_verif = 2;
                        }
                    }
                }
            }
        }
    }

/*
    //3 jewels aligned - row
    for(i = 0 ; i < xdim ; i++)
    {
        for(j = 0 ; j < ydim ; j++)
        {
            if(j+1 < ydim && j+2 < ydim)
            {
                if(table[i][j] == table[i][j+1] && table[i][j] == table[i][j+2])
                {
                    nbAlignR3++;
                    table[i][j] = random_jewel(65,71);
                    table[i][j+1] = random_jewel(65,71);
                    table[i][j+2] = random_jewel(65,71);
                }
            }
        }
    }
*/

/*
    //3 jewels aligned - column
    for(i = 0 ; i < xdim ; i++)
    {
        for(j = 0 ; j < ydim ; j++)
        {
            if(i+1 < xdim && i+2 < xdim)
            {
                if(table[i][j] == table[i+1][j] && table[i][j] == table[i+2][j])
                {
                    nbAlignC3++;
                    table[i][j] = random_jewel(65,71);
                    table[i+1][j] = random_jewel(65,71);
                    table[i+2][j] = random_jewel(65,71);
                }
            }
        }
    }
*/ 
}

bool Grid::swap_jewel (unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2)
{
    int alignR3, alignR4, alignR5, alignC3, alignC4, alignC5;
    
    bool ok = true; //values false when coordinates are false
    char temp; //to save the first cell for the swap, like a buffer variable
    
    //coordinates are in the grid, are different and no too far
    if (x1 < 1 ||  x1 > xdim)
    {
        cout << "Error while entering x1" << endl;
        ok = false;
    }

    if (x2 < 1 || x2 > xdim)
    {
        cout << "Error while entering x2" << endl;
        ok = false;
    }

    if (y1 < 1 ||  y1 > ydim)
    {
        cout << "Error while entering y1" << endl;
        ok = false;
    }

    if (y2 < 1 || y2 > ydim)
    {
        cout << "Error while entering y2" << endl;
        ok = false;
    }

    if (x1 == x2 && y1 == y2)
    {
        cout << "Coordinates are the same" << endl;
        ok = false;
    }
    
    if (((x2 == x1-1 && y2 == y1) || (x2 == x1 && y2 == y1-1) || (x2 == x1+1 && y2 == y1) || (x2 == x1 && y2 == y1+1)) == false)
    {
        cout << "Coordinates are too far away" << endl;
        ok = false;
    }  
    
    if (ok == true)
    {    
        //make the swap  
        //-1 is required because the table is 0 to 7, not 1 to 8 (player)   
        temp = table[y1-1][x1-1]; //save the first cell in order to not loose it between the swap
        table[y1-1][x1-1] = table[y2-1][x2-1];
        table[y2-1][x2-1] = temp;
        
        //verifing that the swap will make an alignment
        alignment_verification(alignR3, alignR4, alignR5, alignC3, alignC4, alignC5);

        //if the swap doesn't make a alignment we re-swap the jewels in order to have the previous grid
        if(alignR3 == 0 && alignR4 == 0 && alignR5 == 0 && alignC3 == 0 && alignC4 == 0 && alignC5 == 0)
        {
            cout << "This movement doesn't form an alignment. Try another !" << endl;

            temp = table[y1-1][x1-1];
            table[y1-1][x1-1] = table[y2-1][x2-1];
            table[y2-1][x2-1] = temp;

            ok = false;
        }

        //else, everything is ok and we increase the score in function of the size of the alignment
        else
        {
            cout << "Mouvement OK !" << endl;
            count_score(alignR3, alignR4, alignR5, alignC3, alignC4, alignC5);
        }
    }

    return ok;
}

void Grid::count_score (int &nbAlignR3, int &nbAlignR4, int &nbAlignR5, int &nbAlignC3, int &nbAlignC4, int &nbAlignC5)
{
    score = score + 10*nbAlignR3 + 10*nbAlignC3
                  + 20*nbAlignR4 + 20*nbAlignC4
                  + 30*nbAlignR5 + 30*nbAlignC5;
                
    cout << "Your score is " << score << " points" << endl;
}

void Grid::set_score (int points)
{
    score = points;
}

int Grid::get_score ()
{
    return score;
}

Jewel Grid::get_jewel(unsigned int x, unsigned int y)
{
    Jewel j; 
    Image im;
    char character = table[x][y]; //the letter representing the jewel
    
    switch (character) 
    {
        case 'A':
        {
            //if the letter is A
            //we create an image and set its surface 
            im.set_surface (SDL_LoadBMP("../data/Aj.bmp") ); 
            j.set_rock(im); //the jewel's rock is now the created image
            j.set_type('A'); //the jewel's type, its letter, is A
            break;
        }

        case 'B':
        {
            im.set_surface (SDL_LoadBMP("../data/Bj.bmp") );
            j.set_rock(im);
            j.set_type('B');
            break;
        }
        
        case 'C':
        {
            im.set_surface (SDL_LoadBMP("../data/Cj.bmp") );
            j.set_rock(im);
            j.set_type('C');
            break;
        }

        case 'D':
        {
            im.set_surface (SDL_LoadBMP("../data/Dj.bmp") );
            j.set_rock(im);
            j.set_type('D');
            break;
        }

        case 'E':
        {
            im.set_surface (SDL_LoadBMP("../data/Ej.bmp") );
            j.set_rock(im);
            j.set_type('E');
            break;
        }

        case 'F':
        {
            im.set_surface (SDL_LoadBMP("../data/Fj.bmp") );
            j.set_rock(im);
            j.set_type('F');
            break;
        }

        case 'G':
        {
            im.set_surface(SDL_LoadBMP("../data/Gj.bmp"));
            j.set_rock(im);
            j.set_type('G');
            break;
        }

        default:
        {
            // operator doesn't match any case 
            cout << "Error!";
            break;
        }
    }
    
    return j;
}

unsigned int Grid::get_xdim() const
{
    return xdim;
}

unsigned int Grid::get_ydim() const
{
    return ydim;
}